from django.urls import path
from inventory import views

urlpatterns = [
    path('', views.home, name='home'),
    path('books/', views.book_manager, name='book-manager'),
    path('books/<str:id>/', views.book_detail, name='book-detail'),
]